package com.GFG_NoSQLAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GfgNoSqlAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(GfgNoSqlAssignmentApplication.class, args);
	}

}
