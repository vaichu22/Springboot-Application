package com.SQLAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GfgSqlAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(GfgSqlAssignmentApplication.class, args);
	}

}
